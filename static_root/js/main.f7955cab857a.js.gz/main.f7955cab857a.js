/**
 * main.js - Core workspace logic, alert dismissals, dialog validations,
 * Chart.js token visualizer, and non-disruptive live status polling.
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // 2. Alert & Toast Notification Management
    initializeAlerts();

    // 3. Settings Modal & Danger Zone Validation
    initializeSettingsModal();

    // 4. Ingest Drag-and-Drop Dropzone
    initializeDragAndDrop();

    // 5. Library Export/Select Checkbox Actions
    initializeExportActions();

    // 6. Semantic RAG Search Panel
    initializeRAGSearch();

    // 7. Chart.js Token Spend Initialization
    initializeTokensChart();

    // 8. Initialize Realtime WebSocket updates or Fallback Poller
    initializeSupabaseRealtime();
});

/**
 * Handle alert-card manual and automatic dismissals with hover pause.
 */
function initializeAlerts() {
    const alertCards = document.querySelectorAll('.alert-card');
    const AUTO_DISMISS_DELAY = 5000;

    alertCards.forEach(card => {
        let dismissTimeout = setTimeout(() => {
            dismissCard(card);
        }, AUTO_DISMISS_DELAY);

        // Pause countdown on hover
        card.addEventListener('mouseenter', () => clearTimeout(dismissTimeout));
        card.addEventListener('mouseleave', () => {
            dismissTimeout = setTimeout(() => {
                dismissCard(card);
            }, AUTO_DISMISS_DELAY);
        });
    });

    // Delegated click for manual dismissal
    document.addEventListener('click', (event) => {
        const btn = event.target.closest('[data-dismiss]');
        if (!btn) return;
        const targetId = btn.getAttribute('data-dismiss');
        const card = document.getElementById(targetId);
        if (card) {
            dismissCard(card);
        }
    });
}

function dismissCard(card) {
    if (!card || card.classList.contains('fade-out')) return;
    card.classList.add('fade-out');
    card.addEventListener('transitionend', function handler(e) {
        if (['opacity', 'max-height', 'transform'].includes(e.propertyName)) {
            card.removeEventListener('transitionend', handler);
            card.remove();
            
            // Clean up alert-container if it becomes empty
            const container = document.querySelector('.alert-container');
            if (container && container.querySelectorAll('.alert-card').length === 0) {
                container.remove();
            }
        }
    });
}

/**
 * Settings dialog modal, backdrop closing, and confirmation logic for danger reset memory.
 */
function initializeSettingsModal() {
    const settingsModal = document.getElementById('settings-modal');
    const settingsTriggerBtn = document.getElementById('settings-trigger-btn');
    const settingsCloseBtn = document.getElementById('settings-close-btn');
    
    const resetTriggerBtn = document.getElementById('reset-trigger-btn');
    const resetCancelBtn = document.getElementById('reset-cancel-btn');
    const resetConfirmInput = document.getElementById('reset_confirm_input');
    const finalResetBtn = document.getElementById('final-reset-btn');

    if (settingsTriggerBtn && settingsModal) {
        settingsTriggerBtn.addEventListener('click', () => {
            settingsModal.showModal();
        });
    }

    if (settingsCloseBtn && settingsModal) {
        settingsCloseBtn.addEventListener('click', () => {
            settingsModal.close();
            cancelResetConfirmation();
        });
    }

    // Backdrop click handling
    if (settingsModal) {
        settingsModal.addEventListener('click', (event) => {
            const rect = settingsModal.getBoundingClientRect();
            const isInDialog = (
                rect.top <= event.clientY && event.clientY <= rect.top + rect.height &&
                rect.left <= event.clientX && event.clientX <= rect.left + rect.width
            );
            if (!isInDialog) {
                settingsModal.close();
                cancelResetConfirmation();
            }
        });
    }

    // Dual action Danger Zone Flow
    if (resetTriggerBtn) {
        resetTriggerBtn.addEventListener('click', () => {
            const initialState = document.getElementById('reset-initial-state');
            const confirmState = document.getElementById('reset-confirm-state');
            if (initialState) initialState.style.display = 'none';
            if (confirmState) confirmState.style.display = 'flex';
            if (resetConfirmInput) {
                resetConfirmInput.value = '';
                resetConfirmInput.focus();
            }
            if (finalResetBtn) {
                finalResetBtn.disabled = true;
            }
        });
    }

    if (resetCancelBtn) {
        resetCancelBtn.addEventListener('click', cancelResetConfirmation);
    }

    if (resetConfirmInput) {
        resetConfirmInput.addEventListener('input', () => {
            if (finalResetBtn) {
                const val = resetConfirmInput.value.trim().toUpperCase();
                finalResetBtn.disabled = (val !== 'RESET');
            }
        });
    }
}

function cancelResetConfirmation() {
    const initialState = document.getElementById('reset-initial-state');
    const confirmState = document.getElementById('reset-confirm-state');
    if (initialState) initialState.style.display = 'block';
    if (confirmState) confirmState.style.display = 'none';
}

/**
 * Handle drag-and-drop file upload zone interaction.
 */
function initializeDragAndDrop() {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const uploadForm = document.getElementById('upload-form');

    if (!dropZone || !fileInput || !uploadForm) return;

    dropZone.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            uploadForm.submit();
        }
    });

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, e => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, e => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
        }, false);
    });

    dropZone.addEventListener('drop', e => {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files.length > 0) {
            fileInput.files = files;
            uploadForm.submit();
        }
    });
}

/**
 * Handle Library Export checklist, Select All / Clear All, and document deletion.
 */
function initializeExportActions() {
    const docSelectors = document.querySelectorAll('.doc-selector');
    const selectAllBtn = document.getElementById('btn-select-all');
    const clearAllBtn = document.getElementById('btn-clear-all');

    if (docSelectors) {
        docSelectors.forEach(cb => {
            cb.addEventListener('change', toggleExportFooter);
        });
    }

    if (selectAllBtn) {
        selectAllBtn.addEventListener('click', () => selectAllCheckbox(true));
    }

    if (clearAllBtn) {
        clearAllBtn.addEventListener('click', () => selectAllCheckbox(false));
    }

    // Deletion click handling delegation
    document.addEventListener('click', (event) => {
        const btn = event.target.closest('.btn-delete-doc');
        if (!btn) return;
        const docId = btn.dataset.docId;
        if (docId && confirm('Are you sure you want to delete this document from the library?')) {
            const form = document.getElementById('delete-form');
            if (form) {
                form.action = `/document/${docId}/delete/`;
                form.submit();
            }
        }
    });
}

function toggleExportFooter() {
    const checkboxes = document.querySelectorAll('.doc-selector:checked');
    const count = checkboxes.length;
    const footer = document.getElementById('export-actions-bar');
    const countLabel = document.getElementById('selected-count');
    
    if (countLabel) countLabel.textContent = count;
    if (footer) {
        if (count > 0) {
            footer.classList.add('visible');
        } else {
            footer.classList.remove('visible');
        }
    }
}

function selectAllCheckbox(select) {
    const checkboxes = document.querySelectorAll('.doc-selector');
    checkboxes.forEach(cb => {
        cb.checked = select;
    });
    toggleExportFooter();
}

/**
 * Vector Search panel querying and grounded Q&A rendering.
 */
function initializeRAGSearch() {
    const ragQuery = document.getElementById('rag-query');
    const ragBtn = document.getElementById('rag-btn');
    const ragLoader = document.getElementById('rag-loader');
    const ragResults = document.getElementById('rag-results-container');
    const ragAnswer = document.getElementById('rag-answer');
    const ragSourcesList = document.getElementById('rag-sources-list');
    const ragSearchForm = document.getElementById('rag-search-form');
    const errorSettingsTrigger = document.getElementById('error-settings-trigger');

    if (ragSearchForm) {
        ragSearchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            runSemanticRAG();
        });
    }

    if (errorSettingsTrigger) {
        errorSettingsTrigger.addEventListener('click', (e) => {
            e.preventDefault();
            const modal = document.getElementById('settings-modal');
            if (modal) modal.showModal();
        });
    }

    function runSemanticRAG() {
        if (!ragQuery || !ragBtn || !ragLoader || !ragResults || !ragAnswer || !ragSourcesList) return;
        const query = ragQuery.value.trim();
        if (!query) return;

        ragLoader.style.display = 'block';
        ragResults.style.display = 'none';
        ragBtn.disabled = true;

        fetch(`/rag-search/?q=${encodeURIComponent(query)}`)
            .then(res => res.json())
            .then(data => {
                ragLoader.style.display = 'none';
                ragBtn.disabled = false;
                
                if (data.error) {
                    alert(data.error);
                    return;
                }

                ragResults.style.display = 'block';
                ragAnswer.innerHTML = data.answer_html;
                
                ragSourcesList.innerHTML = '';
                if (data.sources && data.sources.length > 0) {
                    data.sources.forEach(src => {
                        const li = document.createElement('li');
                        li.style.marginBottom = '6px';
                        li.innerHTML = `<a href="/document/${src.id}/" style="color:var(--accent); text-decoration:none; font-weight:600;">${src.title}</a> (Lang: ${src.language}, Chunk: #${src.chunk_index+1})`;
                        ragSourcesList.appendChild(li);
                    });
                } else {
                    ragSourcesList.innerHTML = '<li>No sources linked</li>';
                }
            })
            .catch(err => {
                ragLoader.style.display = 'none';
                ragBtn.disabled = false;
                alert('An error occurred during vector search.');
                console.error(err);
            });
    }
}

/**
 * Initial global Chart instance pointer for smooth live token updates.
 */
let tokensChartInstance = null;

function initializeTokensChart() {
    const tokensChartEl = document.getElementById('tokensChart');
    if (!tokensChartEl) return;

    const ctx = tokensChartEl.getContext('2d');
    const prompt_tokens = parseInt(tokensChartEl.dataset.prompt || '1', 10);
    const candidates_tokens = parseInt(tokensChartEl.dataset.candidates || '0', 10);
    
    if (typeof Chart !== 'undefined') {
        tokensChartInstance = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Input Prompt', 'Output Reason'],
                datasets: [{
                    data: [prompt_tokens || 1, candidates_tokens || 0],
                    backgroundColor: ['#6366f1', '#a855f7'],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                cutout: '75%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return ` ${context.label}: ${context.raw.toLocaleString()} tokens`;
                            }
                        }
                    }
                }
            }
        });
    }
}

/**
 * Compact helper to format numbers (e.g. 15000 -> 15.0K, 1500000 -> 1.5M).
 */
function formatCompact(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    if (num >= 1000) {
        return (num / 100).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    return num.toString();
}

/**
 * /**
 * Asynchronous Background Status Poller (Fallback).
 * Periodically queries `/api/documents/status/` and updates indicators dynamically.
 */
function initializeStatusPoller() {
    const POLL_INTERVAL = 5000; // 5 seconds
    let activePoll = false;

    // Check if we need to poll immediately
    function checkNeedsPolling() {
        // We poll if there are documents processing/pending on dashboard,
        // or if we are on the document detail screen and the current document is not completed/failed.
        const activeBadges = document.querySelectorAll('.badge-processing, .badge-pending');
        const detailTimelineContainer = document.querySelector('.timeline-container');
        
        let onDetailAndProcessing = false;
        if (detailTimelineContainer) {
            // If on details screen, check if timeline has non-completed states active or if we see a processing box
            const activeSteps = detailTimelineContainer.querySelectorAll('.timeline-step.active');
            const hasCompleted = detailTimelineContainer.querySelectorAll('.timeline-step.completed').length;
            // There are 4 steps total. If completed steps < 4 and there is no failure, we poll.
            const isFailed = document.querySelector('.timeline-step.failed') || document.querySelector('[data-doc-status="FAILED"]');
            if (hasCompleted < 4 && !isFailed) {
                onDetailAndProcessing = true;
            }
        }

        return activeBadges.length > 0 || onDetailAndProcessing;
    }

    if (checkNeedsPolling()) {
        runPoller();
        setInterval(runPoller, POLL_INTERVAL);
    }

    function runPoller() {
        if (activePoll) return;
        activePoll = true;

        fetch('/api/documents/status/')
            .then(res => res.json())
            .then(data => {
                activePoll = false;
                updateDashboardStats(data.stats);
                updateDocumentsTable(data.documents);
                updateDocumentDetailScreen(data);
            })
            .catch(err => {
                activePoll = false;
                console.error('Poller error:', err);
            });
    }
}

/**
 * Supabase Realtime Subscription Integration.
 * Upgrades background polling to instant, native WebSockets when credentials are configured.
 */
function initializeSupabaseRealtime() {
    const supabaseUrl = document.body.dataset.supabaseUrl;
    const supabaseKey = document.body.dataset.supabaseKey;

    if (!supabaseUrl || !supabaseKey || typeof supabase === 'undefined') {
        console.log("[Realtime] Supabase Realtime credentials not detected or SDK not loaded. Falling back to background AJAX polling.");
        initializeStatusPoller();
        return;
    }

    console.log("[Realtime] Upgrading to Supabase Realtime WebSockets...");
    const client = supabase.createClient(supabaseUrl, supabaseKey);

    // Subscribe to UPDATE events on extractor_sourcedocument table
    const channel = client
        .channel('schema-db-changes')
        .on(
            'postgres_changes',
            {
                event: 'UPDATE',
                schema: 'public',
                table: 'extractor_sourcedocument'
            },
            (payload) => {
                console.log('[Realtime] Received document update event:', payload);
                triggerUpdate();
            }
        )
        .subscribe((status) => {
            console.log('[Realtime] Subscription status:', status);
        });

    let activeFetch = false;
    function triggerUpdate() {
        if (activeFetch) return;
        activeFetch = true;
        fetch('/api/documents/status/')
            .then(res => res.json())
            .then(data => {
                activeFetch = false;
                updateDashboardStats(data.stats);
                updateDocumentsTable(data.documents);
                updateDocumentDetailScreen(data);
            })
            .catch(err => {
                activeFetch = false;
                console.error('[Realtime] State update fetch error:', err);
            });
    }
    
    // Initial fetch to load stats and populate active state on page load
    triggerUpdate();
}

/**
 * Shared DOM Update Helpers for Polling and Realtime Channels.
 */

function updateDashboardStats(stats) {
    if (!stats) return;

    // 1. Monthly AI compute spend
    const spendVal = document.querySelector('.metrics-row .metric-card:first-child .metric-value');
    if (spendVal) {
        spendVal.textContent = stats.formatted_monthly_spent;
    }

    const budgetSub = document.querySelector('.metrics-row .metric-card:first-child .metric-sub');
    if (budgetSub) {
        // Find progress fill bar and update style
        const fillBar = budgetSub.querySelector('.budget-bar-fill');
        if (fillBar) {
            fillBar.style.width = stats.percent_spent + '%';
        }
    }

    // 2. Extracted Pages count
    const pagesVal = document.querySelector('.metrics-row .metric-card:nth-child(2) .metric-value');
    if (pagesVal) {
        pagesVal.textContent = stats.total_pages;
    }

    // 3. Active pipelines
    const activeCount = document.getElementById('active-tasks-count');
    if (activeCount) {
        activeCount.textContent = stats.PENDING + stats.EXTRACTING + stats.REFINING + stats.EMBEDDING;
    }

    // 4. Token usage text & Chart
    const tokenContainer = document.querySelector('.metrics-row .metric-card:nth-child(4)');
    if (tokenContainer) {
        const tokenValue = tokenContainer.querySelector('.token-value-text');
        if (tokenValue) {
            tokenValue.textContent = formatCompact(stats.total_tokens);
        }
        const tokenSub = tokenContainer.querySelector('.token-sub-text');
        if (tokenSub) {
            tokenSub.innerHTML = `In: ${formatCompact(stats.prompt_tokens)}<br>Out: ${formatCompact(stats.candidates_tokens)}`;
        }
    }

    if (tokensChartInstance && stats.total_tokens > 0) {
        tokensChartInstance.data.datasets[0].data = [stats.prompt_tokens, stats.candidates_tokens];
        tokensChartInstance.update();
    }

    // 5. Budget Exceeded Alert card logic (dynamic show/hide)
    const billingAlert = document.querySelector('.alert-error');
    if (billingAlert && billingAlert.textContent.includes('Monthly API Billing Cap Triggered')) {
        if (!stats.budget_exceeded) {
            billingAlert.remove();
        }
    } else if (stats.budget_exceeded && !billingAlert) {
        // Reload page once to let Django render the warning beautifully
        location.reload();
    }
}

function updateDocumentsTable(documents) {
    if (!documents) return;
    const tbody = document.querySelector('.files-panel table tbody');
    if (!tbody) return;

    documents.forEach(doc => {
        // Find existing row
        let row = tbody.querySelector(`tr[data-doc-id="${doc.id}"]`);
        
        // If rows don't have data-doc-id, try searching by href or checkbox selector ID
        if (!row) {
            const chk = document.getElementById(`chk-doc-${doc.id}`);
            if (chk) {
                row = chk.closest('tr');
            } else if (doc.uuid) {
                // Search by link matching /document/UUID/
                const link = tbody.querySelector(`a[href*="/document/${doc.uuid}/"]`);
                if (link) {
                    row = link.closest('tr');
                }
            } else {
                // Search by link matching /document/ID/
                const link = tbody.querySelector(`a[href*="/document/${doc.id}/"]`);
                if (link) {
                    row = link.closest('tr');
                }
            }
        }

        if (row) {
            // Keep a record of current status on row
            const previousStatus = row.dataset.status;
            row.dataset.docId = doc.id;
            row.dataset.status = doc.status;

            // If status changed to completed/failed, trigger reload once to get fresh links & checkboxes,
            // or update columns beautifully
            if (previousStatus && previousStatus !== doc.status) {
                if (doc.status === 'COMPLETED' || doc.status === 'FAILED') {
                    // Reloading is safest when transition concludes to let Django render permissions/downloads
                    globalThis.location.reload();
                    return;
                }
            }

            // Update Status Column
            const badgeTd = row.querySelector('td:nth-child(5)');
            if (badgeTd) {
                badgeTd.innerHTML = getStatusBadgeHTML(doc.status, doc.status_display);
            }

            // Update Cost & Token details column
            const costTd = row.querySelector('td:nth-child(4)');
            if (costTd) {
                const costVal = costTd.querySelector('div');
                if (costVal) {
                    costVal.textContent = doc.formatted_cost;
                }
                const costSub = costTd.querySelector('.doc-cost-sub');
                if (costSub && typeof doc.input_tokens !== 'undefined' && typeof doc.output_tokens !== 'undefined') {
                    costSub.textContent = `In: ${formatCompact(doc.input_tokens)} / Out: ${formatCompact(doc.output_tokens)}`;
                }
            }
        }
    });
}

function updateDocumentDetailScreen(data) {
    const detailTimelineContainer = document.querySelector('.timeline-container');
    if (!detailTimelineContainer) return;

    // Get document ID from URL /document/ID/
    const match = globalThis.location.pathname.match(/\/document\/(\d+)\//);
    if (!match) return;
    const docId = parseInt(match[1], 10);

    const currentDoc = data.documents.find(d => d.id === docId);
    if (!currentDoc) return;

    const currentStatus = currentDoc.status;
    
    // Update meta values
    const detailCost = document.getElementById('detail-cost');
    if (detailCost) {
        detailCost.textContent = currentDoc.formatted_cost;
    }

    const detailLang = document.getElementById('detail-lang');
    if (detailLang) {
        if (currentStatus === 'FAILED') {
            detailLang.innerHTML = '<span class="text-danger">Failed</span>';
        } else if (currentStatus === 'PENDING') {
            detailLang.innerHTML = '<span class="text-muted">Queued...</span>';
        } else if (currentDoc.language === 'Unknown') {
            detailLang.innerHTML = '<span class="detecting-pulse"><i data-lucide="loader" class="spinner" style="width:12px; height:12px;"></i> Detecting...</span>';
        } else {
            detailLang.textContent = currentDoc.language;
        }
    }

    const detailAuthor = document.getElementById('detail-author');
    if (detailAuthor) {
        if (currentStatus === 'FAILED') {
            detailAuthor.innerHTML = '<span class="text-danger">Failed</span>';
        } else if (currentStatus === 'PENDING') {
            detailAuthor.innerHTML = '<span class="text-muted">Queued...</span>';
        } else if (currentDoc.author === 'Unknown') {
            detailAuthor.innerHTML = '<span class="detecting-pulse"><i data-lucide="loader" class="spinner" style="width:12px; height:12px;"></i> Detecting...</span>';
        } else {
            detailAuthor.textContent = currentDoc.author;
        }
    }

    // Update active timeline steps
    const steps = detailTimelineContainer.querySelectorAll('.timeline-step');
    if (steps.length >= 4) {
        // Step 2: OCR
        updateTimelineStep(steps[1], ['EXTRACTING'].includes(currentStatus), ['REFINING', 'EMBEDDING', 'COMPLETED'].includes(currentStatus));
        // Step 3: Reasoning
        updateTimelineStep(steps[2], ['REFINING'].includes(currentStatus), ['EMBEDDING', 'COMPLETED'].includes(currentStatus));
        // Step 4: Embedding
        updateTimelineStep(steps[3], ['EMBEDDING'].includes(currentStatus), ['COMPLETED'].includes(currentStatus));
    }

    // Check if finished. If so, reload once to load the rich SFT Q&A + Markdown textareas
    const isCurrentlyProcessing = ['PENDING', 'EXTRACTING', 'REFINING', 'EMBEDDING'].includes(currentStatus);
    const hasEditorForm = document.getElementById('editor-form');
    const hasFailureBoard = document.querySelector('.timeline-step.failed') || document.querySelector('[data-doc-status="FAILED"]');
    
    if (!isCurrentlyProcessing && !hasEditorForm && !hasFailureBoard) {
        globalThis.location.reload();
    }
}

function updateTimelineStep(stepEl, isActive, isCompleted) {
    stepEl.classList.remove('active', 'completed');
    const node = stepEl.querySelector('.step-node');
    
    if (isCompleted) {
        stepEl.classList.add('completed');
        if (node) node.innerHTML = '<i data-lucide="check" style="width:14px; height:14px;"></i>';
    } else if (isActive) {
        stepEl.classList.add('active');
        stepEl.setAttribute('aria-current', 'step');
        if (node) node.innerHTML = '<i data-lucide="loader" class="spinner" style="width:14px; height:14px;"></i>';
    } else {
        // Set index
        const labelText = stepEl.querySelector('.step-label').textContent;
        let idx = '2';
        if (labelText.includes('Reasoning')) idx = '3';
        if (labelText.includes('Vector')) idx = '4';
        if (node) node.textContent = idx;
    }

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function getStatusBadgeHTML(status, display) {
    if (status === 'COMPLETED') {
        return `<span class="badge badge-completed"><i data-lucide="check-circle-2" style="width:12px; height:12px;"></i> ${display}</span>`;
    }
    if (status === 'FAILED') {
        return `<span class="badge badge-failed"><i data-lucide="x-circle" style="width:12px; height:12px;"></i> Failed</span>`;
    }
    if (status === 'PENDING') {
        return `<span class="badge badge-pending"><i data-lucide="clock" style="width:12px; height:12px;"></i> ${display}</span>`;
    }
    // Processing status (EXTRACTING, REFINING, EMBEDDING)
    return `<span class="badge badge-processing"><i data-lucide="loader" class="spinner" style="width:12px; height:12px;"></i> ${display}</span>`;
}

